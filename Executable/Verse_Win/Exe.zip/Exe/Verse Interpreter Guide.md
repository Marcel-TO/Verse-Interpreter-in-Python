# Verse Interpreter Guide
Users interact with the tool by typing commands in the command line interface, instructing the interpreter to interpret and execute their code.
The custom input pointer displayed like this: *`[verse]>>>`* informs the user where he can enter his verse code.

The picture below displays an exemplary use of the verse console interpreter: ![Verse Interpreter](./pictures/console.png)